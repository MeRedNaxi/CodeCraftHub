const mongoose = require('mongoose');

// MongoDB schema model for users
const userSchema = new mongoose.Schema({
  username: { type: String, required: true },
  email: { type: String, required: true },
  password: { type: String, required: true },
  // Add any other user-related fields as needed
});

const User = mongoose.model('User', userSchema);

module.exports = User;